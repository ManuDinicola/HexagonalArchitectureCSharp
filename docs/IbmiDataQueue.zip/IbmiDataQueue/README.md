# IbmiDataQueue

Consommer une data queue IBM i depuis .NET sans réécrire à chaque fois la boucle de lecture, le découpage des messages, le retry et la gestion des messages en erreur.

La bibliothèque ne connaît que des **octets** et des **points d'extension**. Le métier (une facture, une commande...) est un simple plugin.

## Projets

| Projet | Rôle | Dépendances |
|---|---|---|
| `IbmiDataQueue.Core` | Interfaces, pipeline (recevoir → décoder → traiter), retry, dead-letter, télémétrie, `FixedWidthLayout` | aucune |
| `IbmiDataQueue.Testing` | Data queue et dead-letter en mémoire, handler à base de lambda | Core |
| `IbmiDataQueue.Sql` | Lecture via `QSYS2.RECEIVE_DATA_QUEUE` sur n'importe quel `DbConnection` | Core |
| `IbmiDataQueue.Hosting` | `BackgroundService` + `AddDataQueueConsumer<T,...>()` | Core, Microsoft.Extensions.Hosting.Abstractions |

## Points d'extension

```csharp
IDataQueueClient      // lit une queue (SQL, mémoire...)
IMessageCodec<T>      // octets -> T
IMessageHandler<T>    // traitement métier
IDeadLetterSink       // destination des messages non traités (doit être durable)
```

## Garanties

- Le message est **retiré de la queue à la lecture** (`REMOVE => 'YES'`) : livraison « au plus une fois ».
- Pour ne rien perdre, tout message reçu est soit traité, soit écrit dans le dead-letter :
  - décodage refusé (longueur, format) : dead-letter `DecodeFailed`, sans retry ;
  - handler en échec : retry (3 essais par défaut, backoff exponentiel), puis `HandlerFailed` ;
  - arrêt demandé pendant le traitement : dead-letter `Interrupted`, puis l'annulation se propage.
- Si le dead-letter lui-même échoue, l'exception remonte (message perdu, mais erreur visible).
- **Vous devez fournir un `IDeadLetterSink` durable** (table Db2, fichier...). Celui en mémoire sert aux tests.

## Utilisation

```csharp
services.AddSingleton<IDataQueueClient>(new SqlDataQueueClient(async ct =>
{
    var connection = new MyDb2Connection(connectionString);
    await connection.OpenAsync(ct);
    return connection;
}));
services.AddSingleton<IDeadLetterSink, MyDb2DeadLetterSink>();
services.AddDataQueueConsumer<InvoiceRequest, InvoiceRequestCodec, InvoiceRequestHandler>(
    new QueueRef("MYLIB", "INVOICEQ"),
    options => options.Wait = TimeSpan.FromSeconds(30));
```

Codec à largeur fixe (largeurs en **octets**, encodage mono-octet du job émetteur, par exemple IBM500) :

```csharp
Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
var layout = new FixedWidthLayout(Encoding.GetEncoding("IBM500"), [10, 10, 2]);
var fields = layout.Read(payload); // longueur exacte exigée, champs sans remplissage
```

Télémétrie : `AddSource(DataQueueTelemetry.Name)` et `AddMeter(DataQueueTelemetry.Name)` (OpenTelemetry).

## Tester

- `dotnet test --filter Category!=Integration` : tests unitaires (aucun IBM i requis) en domaine neutre « Echo ».
- Cible par défaut : `net11.0`. Pour un SDK plus ancien : `dotnet build -p:DqTfm=net10.0`.

### Tests d'intégration (vrai IBM i)

Projet `IbmiDataQueue.IntegrationTests`. Sans les variables d'environnement ci-dessous, les tests sont **ignorés** (ils n'échouent pas).

| Variable | Rôle |
|---|---|
| `IBMI_HOST` | Hôte IBM i (ex. serveur public PUB400) |
| `IBMI_USER`, `IBMI_PASSWORD` | Identifiants (jamais dans le code) |
| `IBMI_LIBRARY` | Bibliothèque **existante** où créer les queues de test |
| `IBMI_CONNECTION_STRING` | Optionnel : remplace HOST/USER/PASSWORD |
| `IBMI_ODBC_DRIVER` | Optionnel, défaut `IBM i Access ODBC Driver` |
| `IBMI_CODEPAGE` | Optionnel, EBCDIC du job, défaut `37` (500, 1148...) |

```bash
export IBMI_HOST=... IBMI_USER=... IBMI_PASSWORD=... IBMI_LIBRARY=...
dotnet test tests/IbmiDataQueue.IntegrationTests --filter Category=Integration
```

Chaque test crée sa data queue (30 octets, FIFO) avec `QSYS2.QCMDEXC('CRTDTAQ ...')`, l'alimente avec `QSYS2.SEND_DATA_QUEUE_BINARY` (ou `SEND_DATA_QUEUE` pour le texte) puis la supprime. **Aucun programme COBOL, physical file ni terminal n'est nécessaire.**

Prérequis : driver ODBC d'IBM i Access installé (et unixODBC sous Linux). Pour `IBM.Data.Db2`, remplacer uniquement `IntegrationConnection.cs`.

Ce que les tests vérifient :
1. Un message binaire ressort identique (aller-retour).
2. **Une queue vide renvoie zéro ligne après l'attente** : hypothèse centrale de `SqlDataQueueClient`. Si ce test échoue, corriger `ReceiveAsync`.
3. Le pipeline traite un message valide, envoie un message invalide au dead-letter, puis signale la queue vide.
4. Un message texte est converti dans le CCSID du job : ajuster `IBMI_CODEPAGE` si besoin.

> Ces tests n'ont pas pu être exécutés lors de leur écriture (pas d'accès IBM i). Les noms de paramètres des procédures `SEND_DATA_QUEUE*` et le comportement exact de `RECEIVE_DATA_QUEUE` sont à confirmer au premier lancement.

## Prochaines étapes

- Dead-letter SQL (table Db2) et émetteur `QSYS2.SEND_DATA_QUEUE`.
- Tests de contrat identiques sur le client en mémoire et sur le client SQL.
- Test avec une fausse `DbConnection` pour `SqlDataQueueClient`.
- Health check et décodage des champs packed decimal (COMP-3) / zoned.
