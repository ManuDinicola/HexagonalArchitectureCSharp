using Microsoft.Extensions.Hosting;

namespace IbmiDataQueue.Hosting;

public sealed class DataQueueWorker<T> : BackgroundService
{
    private readonly DataQueuePipeline<T> _pipeline;

    public DataQueueWorker(DataQueuePipeline<T> pipeline)
    {
        _pipeline = pipeline;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        // Rend la main tout de suite : le démarrage de l'hôte ne doit pas attendre la première lecture.
        await Task.Yield();
        await _pipeline.RunAsync(stoppingToken).ConfigureAwait(false);
    }
}
