namespace IbmiDataQueue;

public sealed class PipelineOptions
{
    /// <summary>Attente maximale par lecture quand la queue est vide.</summary>
    public TimeSpan Wait { get; set; } = TimeSpan.FromSeconds(30);

    /// <summary>Nombre total d'essais du handler (1 = pas de retry).</summary>
    public int MaxHandlerAttempts { get; set; } = 3;

    /// <summary>Délai avant l'essai suivant, en fonction du numéro de l'essai qui vient d'échouer (1, 2...).</summary>
    public Func<int, TimeSpan> RetryBackoff { get; set; } = attempt => TimeSpan.FromSeconds(Math.Pow(2, attempt - 1));

    /// <summary>Pause de la boucle après une erreur (connexion perdue, dead-letter indisponible...).</summary>
    public TimeSpan ErrorDelay { get; set; } = TimeSpan.FromSeconds(5);

    /// <summary>Appelé pour chaque erreur rencontrée (échec d'un essai, erreur de lecture...). Brancher le logging ici.</summary>
    public Action<Exception>? OnError { get; set; }
}
