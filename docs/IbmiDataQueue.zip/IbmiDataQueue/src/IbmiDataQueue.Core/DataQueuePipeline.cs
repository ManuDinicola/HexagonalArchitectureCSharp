using System.Diagnostics;

namespace IbmiDataQueue;

public enum ProcessResult
{
    NoMessage,
    Handled,
    DeadLettered,
}

/// <summary>
/// Recevoir → décoder → traiter. Un message reçu est toujours soit traité, soit écrit dans le dead-letter
/// (livraison « au plus une fois » côté queue, rendue sûre par le dead-letter). Si le dead-letter échoue,
/// l'exception remonte : le message est alors perdu, mais l'erreur est visible.
/// </summary>
public sealed class DataQueuePipeline<T>
{
    private readonly IDataQueueClient _client;
    private readonly QueueRef _queue;
    private readonly IMessageCodec<T> _codec;
    private readonly IMessageHandler<T> _handler;
    private readonly IDeadLetterSink _deadLetters;
    private readonly PipelineOptions _options;
    private readonly TimeProvider _time;
    private readonly KeyValuePair<string, object?> _queueTag;

    public DataQueuePipeline(
        IDataQueueClient client,
        QueueRef queue,
        IMessageCodec<T> codec,
        IMessageHandler<T> handler,
        IDeadLetterSink deadLetters,
        PipelineOptions? options = null,
        TimeProvider? timeProvider = null)
    {
        ArgumentNullException.ThrowIfNull(client);
        ArgumentNullException.ThrowIfNull(codec);
        ArgumentNullException.ThrowIfNull(handler);
        ArgumentNullException.ThrowIfNull(deadLetters);

        _options = options ?? new PipelineOptions();
        if (_options.MaxHandlerAttempts < 1)
        {
            throw new ArgumentOutOfRangeException(nameof(options), "MaxHandlerAttempts doit valoir au moins 1.");
        }

        _client = client;
        _queue = queue;
        _codec = codec;
        _handler = handler;
        _deadLetters = deadLetters;
        _time = timeProvider ?? TimeProvider.System;
        _queueTag = new KeyValuePair<string, object?>("queue", queue.ToString());
    }

    /// <summary>Traite au plus un message.</summary>
    /// <exception cref="OperationCanceledException">Arrêt demandé. Un message en cours de traitement est d'abord écrit au dead-letter.</exception>
    public async ValueTask<ProcessResult> ProcessNextAsync(CancellationToken cancellationToken)
    {
        var message = await _client.ReceiveAsync(_queue, _options.Wait, cancellationToken).ConfigureAwait(false);
        if (message is null)
        {
            return ProcessResult.NoMessage;
        }

        using var activity = DataQueueTelemetry.ActivitySource.StartActivity("dataqueue.process");
        activity?.SetTag("ibmi.queue", _queue.ToString());
        DataQueueTelemetry.Received.Add(1, _queueTag);

        T decoded;
        try
        {
            decoded = _codec.Decode(message.Payload.Span);
        }
        catch (Exception ex)
        {
            await DeadLetterAsync(message, DeadLetterReason.DecodeFailed, ex, attempts: 0).ConfigureAwait(false);
            return ProcessResult.DeadLettered;
        }

        var attempt = 0;
        try
        {
            while (true)
            {
                attempt++;
                try
                {
                    await _handler.HandleAsync(decoded, cancellationToken).ConfigureAwait(false);
                    DataQueueTelemetry.Handled.Add(1, _queueTag);
                    return ProcessResult.Handled;
                }
                catch (Exception ex) when (!IsShutdown(ex, cancellationToken) && attempt < _options.MaxHandlerAttempts)
                {
                    _options.OnError?.Invoke(ex);
                    await Task.Delay(_options.RetryBackoff(attempt), _time, cancellationToken).ConfigureAwait(false);
                }
                catch (Exception ex) when (!IsShutdown(ex, cancellationToken))
                {
                    await DeadLetterAsync(message, DeadLetterReason.HandlerFailed, ex, attempt).ConfigureAwait(false);
                    return ProcessResult.DeadLettered;
                }
            }
        }
        catch (Exception ex) when (IsShutdown(ex, cancellationToken))
        {
            // Le message n'est plus dans la queue : on le conserve avant de laisser l'arrêt se poursuivre.
            await DeadLetterAsync(message, DeadLetterReason.Interrupted, ex, attempt).ConfigureAwait(false);
            throw;
        }
    }

    /// <summary>Boucle de consommation jusqu'à l'annulation. Les erreurs sont rapportées puis la boucle continue.</summary>
    public async Task RunAsync(CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            try
            {
                await ProcessNextAsync(cancellationToken).ConfigureAwait(false);
            }
            catch (Exception ex) when (IsShutdown(ex, cancellationToken))
            {
                break;
            }
            catch (Exception ex)
            {
                DataQueueTelemetry.Errors.Add(1, _queueTag);
                _options.OnError?.Invoke(ex);
                try
                {
                    await Task.Delay(_options.ErrorDelay, _time, cancellationToken).ConfigureAwait(false);
                }
                catch (OperationCanceledException)
                {
                    break;
                }
            }
        }
    }

    private static bool IsShutdown(Exception exception, CancellationToken cancellationToken) =>
        exception is OperationCanceledException && cancellationToken.IsCancellationRequested;

    private async ValueTask DeadLetterAsync(DataQueueMessage message, DeadLetterReason reason, Exception error, int attempts)
    {
        // CancellationToken.None : même pendant l'arrêt, on ne veut pas perdre le message.
        await _deadLetters
            .WriteAsync(new DeadLetter(_queue, message, reason, error, attempts), CancellationToken.None)
            .ConfigureAwait(false);

        DataQueueTelemetry.DeadLettered.Add(1, new TagList { _queueTag, { "reason", reason.ToString() } });
    }
}
